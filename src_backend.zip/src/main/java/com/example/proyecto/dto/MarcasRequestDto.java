package com.example.proyecto.dto;

import lombok.Data;

@Data
public class MarcasRequestDto {
    private String nombre;
    private String imagenUrl;
}
