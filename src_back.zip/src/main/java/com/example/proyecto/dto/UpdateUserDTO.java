package com.example.proyecto.dto;

import lombok.Data;

@Data
public class UpdateUserDTO {
    private String email;
    //private String direccion;
    private String telefono;
}