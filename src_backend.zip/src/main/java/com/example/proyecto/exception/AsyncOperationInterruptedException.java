package com.example.proyecto.exception;

public class AsyncOperationInterruptedException extends RuntimeException {
    public AsyncOperationInterruptedException(String message) {super(message);}
}
