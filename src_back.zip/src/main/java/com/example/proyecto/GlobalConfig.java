package com.example.proyecto;

public class GlobalConfig {

}
