package com.example.proyecto.domain.enums;

public enum Role {
    ROLE_CLIENTE,
    ROLE_EMPLEADO,
    ROLE_ADMIN
}